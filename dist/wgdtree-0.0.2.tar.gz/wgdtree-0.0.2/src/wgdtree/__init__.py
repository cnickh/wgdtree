#get all our function for easy access

from wgdtree.simulation import sim
from wgdtree.retention_rates import rrates, place_wgd
from wgdtree.rooting import root
from wgdtree.split import break_up
from wgdtree.batch_run import run
