from ete3 import Tree

#   function prototypes

#   def test_root(gene_tree,species_tree,root=cur_root,mode=0)

#       dup, loss, trans = 0
#       event_score = dup + loss + trans

#       return event_score
#
#

#   def find_root(gene_tree,species_tree)
